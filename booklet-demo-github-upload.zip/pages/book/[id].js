import React from 'react';
import { useRouter } from 'next/router';
import Link from 'next/link';
import Navigation from '../../components/Navigation';
import BookCard from '../../components/BookCard';
import { books, users, getUsersByBook } from '../../data/mockData';

export default function BookPage() {
  const router = useRouter();
  const { id } = router.query;
  
  // Default to first book if no ID is provided
  const bookId = id ? parseInt(id) : 1;
  const book = books.find(b => b.id === bookId) || books[0];
  
  // Get users who read this book
  const readers = getUsersByBook(bookId);
  
  return (
    <div className="book-detail-page">
      <Navigation activePage="explore" />
      
      <main className="container">
        <div className="back-link">
          <Link href="/explore">
            <a>← Back to Explore</a>
          </Link>
        </div>
        
        <div className="book-detail-container">
          <div className="book-cover-large">
            <img src={book.coverImage || "/placeholder-book-large.jpg"} alt={book.title} />
          </div>
          
          <div className="book-info-container">
            <h2 className="book-title">{book.title}</h2>
            <h3 className="book-author">{book.author}</h3>
            
            <div className="book-metadata">
              <span className="book-genre">{book.genre}</span>
              <span className="book-year">{book.year}</span>
              <span className="book-pages">{book.pages} pages</span>
            </div>
            
            <div className="book-description">
              <p>{book.description}</p>
            </div>
            
            <div className="book-actions">
              <button className="btn-primary">Add to My Books</button>
              <button className="btn-secondary">Add to Wishlist</button>
              <button className="btn-secondary">Mark as Available to Share</button>
            </div>
          </div>
        </div>
        
        <div className="book-community-section">
          <div className="section-tabs">
            <button className="tab-btn active">Who Read This</button>
            <button className="tab-btn">Quotes</button>
            <button className="tab-btn">Discussions</button>
          </div>
          
          <div className="tab-content">
            <h3>Readers of "{book.title}"</h3>
            <p className="readers-count">{readers.length} Booklet members have read this book</p>
            
            <div className="readers-grid">
              {readers.map(user => (
                <div key={user.id} className="user-card">
                  <div className="user-avatar">
                    <img src={user.avatar || "/placeholder-user.jpg"} alt={user.name} />
                  </div>
                  <div className="user-info">
                    <h4 className="user-name">{user.name}</h4>
                    <p className="user-bio">{user.bio}</p>
                    <div className="user-books">
                      {user.favoriteBooks.slice(0, 3).map(bookId => {
                        const userBook = books.find(b => b.id === bookId);
                        return (
                          <div key={bookId} className="user-book-mini">
                            <img src={userBook?.coverImage || "/placeholder-mini.jpg"} alt="Book cover" />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  <button className="btn-connect">Connect</button>
                </div>
              ))}
            </div>
            
            {readers.length > 3 && (
              <button className="btn-view-more">View More Readers</button>
            )}
          </div>
        </div>
        
        <div className="conversation-starter card">
          <h3>Start a Conversation</h3>
          <p>Connect with others who have read "{book.title}" by starting a meaningful conversation.</p>
          
          <div className="conversation-prompts">
            <div className="prompt-card">
              <p>"What was your favorite part of this book and why did it resonate with you?"</p>
              <button className="btn-use-prompt">Use This Prompt</button>
            </div>
            
            <div className="prompt-card">
              <p>"How did this book change your perspective or challenge your thinking?"</p>
              <button className="btn-use-prompt">Use This Prompt</button>
            </div>
            
            <div className="prompt-card">
              <p>"If you could ask the author one question about this book, what would it be?"</p>
              <button className="btn-use-prompt">Use This Prompt</button>
            </div>
          </div>
          
          <div className="custom-prompt">
            <textarea placeholder="Or write your own conversation starter..."></textarea>
            <button className="btn-primary">Start Conversation</button>
          </div>
        </div>
      </main>
      
      <style jsx>{`
        .book-detail-page {
          min-height: 100vh;
          background-color: var(--background-color);
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 1rem;
        }
        
        .back-link {
          margin-bottom: 1.5rem;
        }
        
        .back-link a {
          color: var(--primary-color);
          text-decoration: none;
          font-weight: 500;
        }
        
        .book-detail-container {
          display: grid;
          grid-template-columns: 300px 1fr;
          gap: 2rem;
          margin-bottom: 3rem;
        }
        
        .book-cover-large {
          width: 100%;
          height: 450px;
          border-radius: var(--border-radius);
          overflow: hidden;
          box-shadow: var(--box-shadow);
        }
        
        .book-cover-large img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .book-title {
          font-size: 2rem;
          margin-bottom: 0.5rem;
        }
        
        .book-author {
          color: var(--light-text);
          font-weight: 500;
          margin-bottom: 1rem;
        }
        
        .book-metadata {
          display: flex;
          gap: 1.5rem;
          margin-bottom: 1.5rem;
        }
        
        .book-metadata span {
          color: var(--light-text);
        }
        
        .book-description {
          margin-bottom: 2rem;
        }
        
        .book-description p {
          margin-bottom: 1rem;
          line-height: 1.7;
        }
        
        .book-actions {
          display: flex;
          gap: 1rem;
          margin-bottom: 2rem;
        }
        
        .btn-primary {
          background-color: var(--primary-color);
          color: white;
          border: none;
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-weight: 600;
        }
        
        .btn-secondary {
          background-color: white;
          color: var(--primary-color);
          border: 1px solid var(--primary-color);
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-weight: 600;
        }
        
        .book-community-section {
          margin-bottom: 3rem;
        }
        
        .section-tabs {
          display: flex;
          border-bottom: 1px solid #ddd;
          margin-bottom: 1.5rem;
        }
        
        .tab-btn {
          background: none;
          border: none;
          padding: 1rem 1.5rem;
          cursor: pointer;
          font-weight: 600;
          color: var(--light-text);
        }
        
        .tab-btn.active {
          color: var(--primary-color);
          border-bottom: 2px solid var(--primary-color);
        }
        
        .readers-count {
          color: var(--light-text);
          margin-bottom: 1.5rem;
        }
        
        .readers-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 1.5rem;
          margin-bottom: 1.5rem;
        }
        
        .user-card {
          display: flex;
          flex-direction: column;
          padding: 1.5rem;
          border-radius: var(--border-radius);
          background-color: var(--card-background);
          box-shadow: var(--box-shadow);
        }
        
        .user-avatar {
          width: 80px;
          height: 80px;
          border-radius: 50%;
          overflow: hidden;
          margin-bottom: 1rem;
        }
        
        .user-avatar img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .user-name {
          margin-bottom: 0.5rem;
        }
        
        .user-bio {
          color: var(--light-text);
          font-size: 0.9rem;
          margin-bottom: 1rem;
        }
        
        .user-books {
          display: flex;
          gap: 0.5rem;
          margin-bottom: 1rem;
        }
        
        .user-book-mini {
          width: 40px;
          height: 60px;
          border-radius: 4px;
          overflow: hidden;
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        
        .user-book-mini img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }
        
        .btn-connect {
          background-color: var(--primary-color);
          color: white;
          border: none;
          padding: 0.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-weight: 600;
          margin-top: auto;
        }
        
        .btn-view-more {
          display: block;
          width: fit-content;
          margin: 0 auto;
          background-color: white;
          color: var(--primary-color);
          border: 1px solid var(--primary-color);
          padding: 0.75rem 1.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-weight: 600;
        }
        
        .conversation-starter {
          padding: 2rem;
        }
        
        .conversation-starter h3 {
          margin-bottom: 1rem;
        }
        
        .conversation-starter > p {
          margin-bottom: 1.5rem;
        }
        
        .conversation-prompts {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 1.5rem;
          margin-bottom: 2rem;
        }
        
        .prompt-card {
          background-color: var(--secondary-color);
          padding: 1.5rem;
          border-radius: var(--border-radius);
          display: flex;
          flex-direction: column;
          height: 100%;
        }
        
        .prompt-card p {
          margin-bottom: 1.5rem;
          flex: 1;
        }
        
        .btn-use-prompt {
          background-color: var(--accent-color);
          color: white;
          border: none;
          padding: 0.5rem;
          border-radius: var(--border-radius);
          cursor: pointer;
          font-weight: 600;
          align-self: flex-end;
        }
        
        .custom-prompt {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }
        
        .custom-prompt textarea {
          width: 100%;
          height: 100px;
          padding: 1rem;
          border: 1px solid #ddd;
          border-radius: var(--border-radius);
          font-family: var(--font-family);
          resize: vertical;
        }
        
        .custom-prompt button {
          align-self: flex-end;
        }
        
        .card {
          background-color: var(--card-background);
          border-radius: var(--border-radius);
          box-shadow: var(--box-shadow);
        }
        
        @media (max-width: 768px) {
          .book-detail-container {
            grid-template-columns: 1fr;
          }
          
          .book-cover-large {
            height: 400px;
            max-width: 300px;
            margin: 0 auto;
          }
          
          .readers-grid {
            grid-template-columns: repeat(2, 1fr);
          }
          
          .conversation-prompts {
            grid-template-columns: 1fr;
          }
        }
        
        @media (max-width: 480px) {
          .book-actions {
            flex-direction: column;
          }
          
          .readers-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>
    </div>
  );
}
